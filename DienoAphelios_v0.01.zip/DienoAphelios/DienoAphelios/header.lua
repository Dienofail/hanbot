return {
  id = "daphelios",
  name = "Dieno Aphelios",
  riot = true,
  type = "Champion",
  load = function()
    return player.charName == "Aphelios"
  end
}
