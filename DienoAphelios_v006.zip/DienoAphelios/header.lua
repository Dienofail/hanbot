return {
  id = "daphelios",
  name = "DienoAphelios",
  riot = true,
  type = "Champion",
  load = function()
    return player.charName == "Aphelios"
  end
}
