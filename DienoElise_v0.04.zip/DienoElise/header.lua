return {
  id = "delise",
  name = "Dieno Elise",
  riot = true,
  type = "Champion",
  load = function()
    return player.charName == "Elise"
  end
}
