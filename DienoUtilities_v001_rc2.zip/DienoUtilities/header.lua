return {
  id = "dutilities",
  name = "Dienoutilities",
  riot = true,
  type = "Utility",
  load = function()
    return true
  end
}
